package com.functionalInterface.org;

public interface FunInterface {
	
int doImplementation(int a,int b);
}
