package com.markerInterface.org;

public interface cloneable {

}
