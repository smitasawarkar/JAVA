package com.AbstractFactoryPattern.org;

class BussinessLoan extends Loan {
	public void getInterestRate(double r) {
		rate = r;
	}

}
