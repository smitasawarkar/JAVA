package com.AbstractFactoryPattern.org;

public interface Bank {
	 String getBankName(); 
}
