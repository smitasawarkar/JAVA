package com.AbstractFactoryPattern.org;

class EducationLoan extends Loan{  
	     public void getInterestRate(double r){  
	       rate=r;  
	 }  
	}
