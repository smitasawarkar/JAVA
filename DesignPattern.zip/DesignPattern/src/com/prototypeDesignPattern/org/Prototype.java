package com.prototypeDesignPattern.org;

public interface Prototype {
	
	  public Prototype getClone(); 
	
}

