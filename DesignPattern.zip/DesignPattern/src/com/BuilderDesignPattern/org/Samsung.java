package com.BuilderDesignPattern.org;

public class Samsung extends Company {

	@Override
	public int price() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String pack() {
		// TODO Auto-generated method stub
		return null;
	}

}
