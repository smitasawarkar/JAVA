package com.BuilderDesignPattern.org;

public abstract class CD implements Packing {
	public abstract String pack();
}