package com.BuilderDesignPattern.org;

public interface Packing {
	public String pack();

	public int price();
}