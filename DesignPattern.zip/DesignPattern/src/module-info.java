/**
 * 
 */
/**
 * @author smitas
 *
 */
module PrototypeDesignPattern {
	requires java.sql;
}