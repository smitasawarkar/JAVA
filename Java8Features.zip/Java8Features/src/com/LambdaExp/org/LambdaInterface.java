package com.LambdaExp.org;

public interface LambdaInterface {

	int add(int a,int b);
}
