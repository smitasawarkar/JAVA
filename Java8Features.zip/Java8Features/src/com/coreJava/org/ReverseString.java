package com.coreJava.org;

public class ReverseString {

	public static void main(String[] args) {
	String s1="Smita";
	String revstr="";
	
	for(int i=s1.length()-1; i>=0;i--)
	{
		 revstr=revstr+s1.charAt(i);
	}
	System.out.println(revstr);
	}

}
