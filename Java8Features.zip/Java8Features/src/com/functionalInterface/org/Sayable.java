package com.functionalInterface.org;

@FunctionalInterface
public interface Sayable extends Doable{

public void say(String msg);	
	
}
