package com.methodReferances.org;

public class StaticArithmetic {

	public static int add(int a, int b)
	{
		return a+b;
	}
	public static float add(int a, float b)
	{
		return a+b;
	}
	public static float add(float a, float b)
	{
		return a+b;
	}
	
}
