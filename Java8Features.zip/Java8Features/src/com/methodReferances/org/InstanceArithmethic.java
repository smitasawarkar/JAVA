package com.methodReferances.org;

public class InstanceArithmethic {

	public int addition(int a, int b)
	{
		return a+b;
	}
}
